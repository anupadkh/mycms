from django.apps import AppConfig


class FormentryConfig(AppConfig):
    name = 'formentry'
