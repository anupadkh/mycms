# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models

# Create your models here.
from personal.submodels.person import *
from personal.submodels.family import *
from personal.submodels.formentry import *
# from submodels/incomes.py import *
# from submodels/education.py import *
# from submodels/myproperty.py import *
# from submodels/services.py import *
